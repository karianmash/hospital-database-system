# hospital-database-system

A PHP MySQL system that is used to manage hospital equipments
